# Add all your Python calls here:
python truthfulqa.py facebook/opt-125m
python truthfulqa.py facebook/opt-350m
# ... etc.